# Vector IO - Utility for working with vector data


## Requirements
- python3.7 e pip3 (ou pip3.7)
- gdal >= 2.2
