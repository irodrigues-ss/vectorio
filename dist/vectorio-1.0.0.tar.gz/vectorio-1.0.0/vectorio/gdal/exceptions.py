#!-*-coding:utf-8-*-


class GDALSelfIntersectionGeometry(Exception):
    pass


class GDALBadClosedPolygon(Exception):
    pass


class GDALUnknownException(Exception):
    pass
