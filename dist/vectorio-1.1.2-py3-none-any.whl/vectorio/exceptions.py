from vectorio.vector.exceptions import *
from vectorio.gdal.exceptions import *