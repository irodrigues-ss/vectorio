rm -rf build/ dist/ vectorio.egg-info/
python setup.py build bdist bdist_wheel
